-- ==========================================================
-- REMORAS · Bitácora de Procedimientos
-- Ejecutar completo en Supabase: Panel > SQL Editor > New query > Run
-- ==========================================================

create table if not exists procedimientos (
  id                    text primary key,
  numero                text,
  nombre                text,
  modo                  text,
  variante              text,
  codigo                text,
  etapa_num             text,
  etapa_titulo          text,
  etapa_desc            text,
  centro                text,
  barco                 text,
  fecha_grabacion       date,
  estado_grabacion      text default 'Pendiente',
  rev1_prev_estado      text default 'Pendiente',
  rev1_prev_obs         text,
  rev1_ops_estado       text default 'Pendiente',
  rev1_ops_obs          text,
  estado_edicion        text default 'Pendiente',
  rev2_prev_encargado   text,
  rev2_prev_estado      text default 'Pendiente',
  rev2_prev_obs         text,
  rev2_ops_encargado    text,
  rev2_ops_estado       text default 'Pendiente',
  rev2_ops_obs          text,
  obs_mantencion        text,
  validado              text default 'Pendiente',
  link_manual           text,
  link_capsula          text,
  link_procedimiento    text,
  imagen_portada        text,
  nota_produccion       text,
  updated_at            timestamptz default now()
);

-- Actualiza updated_at automáticamente en cada edición
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_procedimientos_updated_at on procedimientos;
create trigger trg_procedimientos_updated_at
before update on procedimientos
for each row execute function set_updated_at();

-- Seguridad: cualquier persona con el enlace puede LEER;
-- solo un usuario autenticado (tu cuenta admin) puede escribir/editar/eliminar.
alter table procedimientos enable row level security;

drop policy if exists "lectura publica" on procedimientos;
create policy "lectura publica" on procedimientos
  for select using (true);

drop policy if exists "escritura autenticada" on procedimientos;
create policy "escritura autenticada" on procedimientos
  for insert with check (auth.role() = 'authenticated');

drop policy if exists "actualizacion autenticada" on procedimientos;
create policy "actualizacion autenticada" on procedimientos
  for update using (auth.role() = 'authenticated');

drop policy if exists "eliminacion autenticada" on procedimientos;
create policy "eliminacion autenticada" on procedimientos
  for delete using (auth.role() = 'authenticated');

-- Activa las actualizaciones en vivo (realtime) para esta tabla
alter publication supabase_realtime add table procedimientos;
