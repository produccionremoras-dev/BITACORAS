# Bitácora de Procedimientos REMORAS — versión Supabase + Vercel

Esta carpeta contiene una versión **independiente** de la bitácora (no depende de Claude.ai):
sitio estático (`index.html`) + base de datos en Supabase, desplegable gratis en Vercel.

No pude crear las cuentas ni ejecutar el despliegue por ti (no tengo acceso a Vercel ni a
Supabase), pero todo el código está listo — son ~10 minutos de pasos manuales, sin escribir código.

## Contenido de la carpeta
- `index.html` — la aplicación completa (interfaz + lógica + los 60 procedimientos de arranque).
- `schema.sql` — crea la tabla, los permisos de seguridad y activa las actualizaciones en vivo.
- Este `README.md`.

---

## Paso 1 — Crear el proyecto en Supabase (gratis)
1. Ve a https://supabase.com → "Start your project" → crea una cuenta (puedes usar GitHub o correo).
2. "New project" → ponle un nombre (ej. `remoras-bitacora`), elige una contraseña de base de datos
   (guárdala, no la necesitarás en el día a día) y la región más cercana (São Paulo o similar).
3. Espera ~2 minutos a que se aprovisione.

## Paso 2 — Crear la tabla
1. En el panel izquierdo, entra a **SQL Editor** → **New query**.
2. Abre `schema.sql` de esta carpeta, copia todo su contenido y pégalo ahí.
3. Click **Run**. Deberías ver "Success. No rows returned".

Esto crea la tabla `procedimientos`, activa la seguridad (cualquiera puede leer, solo tu cuenta
puede escribir) y habilita las actualizaciones en vivo.

## Paso 3 — Crear tu usuario administrador
1. Ve a **Authentication** → **Users** → **Add user** → **Create new user**.
2. Pon tu correo y una contraseña. Esta será tu cuenta para **editar** la bitácora.
3. Ve a **Authentication** → **Providers** → **Email** → desactiva **"Allow new users to sign up"**.
   Así nadie más puede crearse una cuenta y obtener acceso de edición — solo tú.

## Paso 4 — Copiar tus credenciales
1. Ve a **Project Settings** (ícono de engranaje) → **API**.
2. Copia el **Project URL** y la **anon public key**.
3. Abre `index.html` en un editor de texto, busca estas dos líneas cerca del inicio del `<script>`:
   ```js
   var SUPABASE_URL = "TU_SUPABASE_URL_AQUI";
   var SUPABASE_ANON_KEY = "TU_SUPABASE_ANON_KEY_AQUI";
   ```
   Reemplázalas por tus valores reales y guarda el archivo.

## Paso 5 — Publicar en Vercel (gratis)
**Opción sin usar terminal:**
1. Ve a https://vercel.com/new y crea una cuenta (puedes usar GitHub).
2. Elige **"Deploy"** → en la parte de "Import Project" busca la opción para subir una carpeta
   directamente (drag-and-drop), y arrastra esta carpeta completa (`remoras-bitacora-supabase`).
3. No necesita configuración de build: es un sitio estático. Click **Deploy**.
4. En 1-2 minutos tendrás una URL pública tipo `https://remoras-bitacora.vercel.app`.

**Opción con GitHub (recomendada si vas a seguir editando):**
1. Sube esta carpeta a un repositorio nuevo en GitHub.
2. En Vercel: **Add New... → Project** → importa ese repositorio → Deploy.
3. Cada vez que subas un cambio al repositorio, Vercel lo publica automáticamente.

## Paso 6 — Probar
1. Abre la URL de Vercel. Verás la bitácora en modo lectura ("En vivo · solo lectura").
2. Click **"Iniciar sesión"**, entra con el correo/contraseña que creaste en el Paso 3.
3. Edita o crea un procedimiento y guarda.
4. Abre el mismo enlace en otro navegador o en el celular de otra persona: debería
   actualizarse automáticamente sin recargar la página.

---

## Notas
- **Imágenes de portada:** por ahora se usan como enlace (URL), igual que el manual y la
  cápsula de seguridad — pega el link de una imagen ya subida (Drive, Google Photos, etc. con
  enlace público). Si más adelante quieres subir las imágenes directamente desde la app, se puede
  agregar usando el almacenamiento de archivos de Supabase (Storage) — es un paso adicional.
- **Más de un editor:** repite el Paso 3 para crear una cuenta por cada persona que necesite
  permiso de edición (por ejemplo, Prevención u Operaciones). Todas las cuentas creadas ahí
  tendrán acceso completo de edición; si necesitas permisos distintos por área, se puede afinar
  la regla de seguridad en `schema.sql`.
- **Costo:** el plan gratuito de Supabase y de Vercel alcanza cómodamente para este uso (60-200
  procedimientos, un equipo pequeño). No deberías pagar nada salvo que el proyecto crezca mucho.
